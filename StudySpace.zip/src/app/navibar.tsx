import React from "react";

const navibar = () => {
  return (
    <div>
      <div>
        <p>Profile</p>
      </div>
    </div>
  );
};

export default navibar;
